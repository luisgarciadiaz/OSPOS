<?php 

$lang["error_no_permission_module"] = "You do not have the permission to access the module named";
$lang["error_unknown"] = "Unexpected error";
