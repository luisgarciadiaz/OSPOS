<?php 

$lang["tables_all"] = "Mind";
$lang["tables_columns"] = "Oszlopok";
$lang["tables_hide_show_pagination"] = "Lapozó elrejtése/megjelenítése";
$lang["tables_loading"] = "Betöltés, kérem várjon...";
$lang["tables_page_from_to"] = "Megjelenítve  {0}  {1} / {2} összesen";
$lang["tables_refresh"] = "Frissítés";
$lang["tables_rows_per_page"] = "{0} rekord per oldal";
$lang["tables_toggle"] = "Váltás";
