<?php 

$lang["enum_half_down"] = "Demi-bas";
$lang["enum_half_even"] = "La moitié";
$lang["enum_half_five"] = "Moitié de cinq";
$lang["enum_half_odd"] = "Moitié impair";
$lang["enum_half_up"] = "À moitié";
$lang["enum_round_down"] = "Arrondir vers le bas";
$lang["enum_round_up"] = "Rassembler";
