<?php 

$lang["datepicker_all_time"] = "Vše";
$lang["datepicker_apply"] = "Použít";
$lang["datepicker_cancel"] = "Zrušit";
$lang["datepicker_custom"] = "Jiný";
$lang["datepicker_from"] = "Od";
$lang["datepicker_last_30"] = "Posledních 30 dnů";
$lang["datepicker_last_7"] = "Posledních 7 dnů";
$lang["datepicker_last_financial_year"] = "Minulý účetní rok";
$lang["datepicker_last_month"] = "Minulý měsíc";
$lang["datepicker_last_year"] = "Minulý rok";
$lang["datepicker_same_month_last_year"] = "Stejný měsíc v loňském roce";
$lang["datepicker_same_month_to_same_day_last_year"] = "Stejné období loni";
$lang["datepicker_this_financial_year"] = "Aktuální účetní rok";
$lang["datepicker_this_month"] = "Tento měsíc";
$lang["datepicker_this_year"] = "Tento rok";
$lang["datepicker_to"] = "Do";
$lang["datepicker_today"] = "Dnes";
$lang["datepicker_today_last_year"] = "Stejný den loni";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "Včera";
