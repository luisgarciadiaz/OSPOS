<?php 

$lang["login_gcaptcha"] = "أنا لست بوت.";
$lang["login_go"] = "البدء";
$lang["login_invalid_gcaptcha"] = "رمز التحقق غير صحيح.";
$lang["login_invalid_installation"] = "يوجد مشكلة بالتنصيب, الرجاء التحقق من ملف php.ini.";
$lang["login_invalid_username_and_password"] = "اسم مستخدم/كلمة سر غير صحيح.";
$lang["login_login"] = "دخول";
$lang["login_password"] = "كلمة السر";
$lang["login_username"] = "اسم المستخدم";
